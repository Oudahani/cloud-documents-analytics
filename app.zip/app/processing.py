from typing import List, Dict
import PyPDF2
import docx
import boto3
import os
from .storage import storage

class DocumentProcessor:
    def __init__(self):
        self.s3_client = boto3.client('s3')
        self.bucket_name = storage.bucket_name
        
    def search_documents(self, query: str) -> List[Dict]:
        """Search documents for specific text"""
        results = []
        files = storage.list_files()
        
        for file in files:
            try:
                # Download file temporarily
                temp_path = f"/tmp/{file['filename']}"
                self.s3_client.download_file(self.bucket_name, file['filename'], temp_path)
                
                # Search in file
                matches = self._search_in_file(temp_path, query)
                
                if matches:
                    results.append({
                        "filename": file['filename'],
                        "title": file.get('title', ''),
                        "matches": matches
                    })
                
                # Clean up
                os.remove(temp_path)
                
            except Exception as e:
                print(f"Error processing {file['filename']}: {str(e)}")
                
        return results
    
    def _search_in_file(self, file_path: str, query: str) -> List[Dict]:
        """Search for text in a file and return matches with context"""
        matches = []
        
        if file_path.endswith('.pdf'):
            with open(file_path, 'rb') as file:
                pdf = PyPDF2.PdfReader(file)
                for page_num, page in enumerate(pdf.pages):
                    text = page.extract_text()
                    if query.lower() in text.lower():
                        # Get surrounding context
                        start = max(0, text.lower().find(query.lower()) - 50)
                        end = min(len(text), text.lower().find(query.lower()) + len(query) + 50)
                        context = text[start:end]
                        
                        matches.append({
                            "page": page_num + 1,
                            "context": context,
                            "highlight": query
                        })
                        
        elif file_path.endswith('.docx'):
            doc = docx.Document(file_path)
            for para_num, para in enumerate(doc.paragraphs):
                if query.lower() in para.text.lower():
                    matches.append({
                        "paragraph": para_num + 1,
                        "context": para.text,
                        "highlight": query
                    })
                    
        return matches
    
    def sort_documents(self, sort_by: str = 'title') -> List[Dict]:
        """Sort documents by specified criteria"""
        files = storage.list_files()
        
        if sort_by == 'title':
            return sorted(files, key=lambda x: x.get('title', '').lower())
        elif sort_by == 'size':
            return sorted(files, key=lambda x: x.get('size', 0))
        elif sort_by == 'date':
            return sorted(files, key=lambda x: x.get('last_modified', ''))
        else:
            return files

processor = DocumentProcessor() 