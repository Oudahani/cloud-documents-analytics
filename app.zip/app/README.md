# Cloud-Based Document Analytics System

A FastAPI-based service for managing, searching, sorting, and classifying documents in the cloud.

## Features

- Cloud storage for PDF and Word documents
- Document search with context and highlighting
- Document sorting by title, size, or date
- Automatic document classification
- Collection statistics and analytics
- RESTful API interface

## Prerequisites

- Python 3.7+
- AWS Account with S3 access
- AWS CLI configured (optional)

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd <repository-name>
```

2. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Set up environment variables:
```bash
export S3_BUCKET_NAME=your-bucket-name
export AWS_ACCESS_KEY_ID=your-access-key
export AWS_SECRET_ACCESS_KEY=your-secret-key
```

## Running the Application

Start the server:
```bash
uvicorn main:app --reload
```

The API will be available at `http://localhost:8000`

## API Endpoints

- `POST /upload`: Upload new documents
- `GET /documents`: List all documents (optional sorting)
- `GET /search`: Search documents with highlighting
- `POST /classify`: Classify all documents
- `GET /stats`: Get collection statistics

## API Documentation

Once the server is running, visit:
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## Example Usage

1. Upload a document:
```bash
curl -X POST "http://localhost:8000/upload" -H "accept: application/json" -H "Content-Type: multipart/form-data" -F "file=@document.pdf"
```

2. Search documents:
```bash
curl -X GET "http://localhost:8000/search?query=your+search+terms"
```

3. Get statistics:
```bash
curl -X GET "http://localhost:8000/stats"
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details. 