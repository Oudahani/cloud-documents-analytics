from typing import List, Dict
import boto3
import os
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from .storage import storage

class DocumentClassifier:
    def __init__(self):
        self.s3_client = boto3.client('s3')
        self.bucket_name = storage.bucket_name
        self.categories = {
            'technical': ['code', 'programming', 'software', 'hardware', 'system'],
            'business': ['finance', 'marketing', 'sales', 'management', 'strategy'],
            'legal': ['law', 'contract', 'agreement', 'regulation', 'compliance'],
            'academic': ['research', 'study', 'analysis', 'thesis', 'paper']
        }
        self.vectorizer = TfidfVectorizer()
        self.classifier = MultinomialNB()
        
    def classify_all(self) -> List[Dict]:
        """Classify all documents in storage"""
        files = storage.list_files()
        results = []
        
        for file in files:
            try:
                # Download file temporarily
                temp_path = f"/tmp/{file['filename']}"
                self.s3_client.download_file(self.bucket_name, file['filename'], temp_path)
                
                # Extract text and classify
                text = self._extract_text(temp_path)
                category = self._classify_text(text)
                
                results.append({
                    "filename": file['filename'],
                    "title": file.get('title', ''),
                    "category": category
                })
                
                # Clean up
                os.remove(temp_path)
                
            except Exception as e:
                print(f"Error classifying {file['filename']}: {str(e)}")
                
        return results
    
    def _extract_text(self, file_path: str) -> str:
        """Extract text from document"""
        import PyPDF2
        import docx
        
        text = ""
        
        if file_path.endswith('.pdf'):
            with open(file_path, 'rb') as file:
                pdf = PyPDF2.PdfReader(file)
                for page in pdf.pages:
                    text += page.extract_text() + "\n"
                    
        elif file_path.endswith('.docx'):
            doc = docx.Document(file_path)
            for para in doc.paragraphs:
                text += para.text + "\n"
                
        return text
    
    def _classify_text(self, text: str) -> str:
        """Classify text using keyword matching"""
        text = text.lower()
        max_matches = 0
        best_category = 'other'
        
        for category, keywords in self.categories.items():
            matches = sum(1 for keyword in keywords if keyword in text)
            if matches > max_matches:
                max_matches = matches
                best_category = category
                
        return best_category

classifier = DocumentClassifier() 