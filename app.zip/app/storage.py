import os
from fastapi import UploadFile
from typing import List, Dict
import PyPDF2
import docx
from datetime import datetime
import boto3
from botocore.exceptions import ClientError

class DocumentStorage:
    def __init__(self):
        self.s3_client = boto3.client('s3')
        self.bucket_name = os.getenv('S3_BUCKET_NAME', 'document-analytics-bucket')
        
    async def save_file(self, file: UploadFile) -> Dict:
        """Save uploaded file to cloud storage and extract metadata"""
        try:
            # Save file to temporary location
            temp_path = f"/tmp/{file.filename}"
            with open(temp_path, "wb") as buffer:
                content = await file.read()
                buffer.write(content)
            
            # Extract metadata
            metadata = self._extract_metadata(temp_path)
            
            # Upload to S3
            self.s3_client.upload_file(
                temp_path,
                self.bucket_name,
                file.filename,
                ExtraArgs={'Metadata': metadata}
            )
            
            # Clean up
            os.remove(temp_path)
            
            return {
                "filename": file.filename,
                "size": len(content),
                "upload_time": datetime.now().isoformat(),
                **metadata
            }
            
        except Exception as e:
            raise Exception(f"Failed to save file: {str(e)}")
    
    def _extract_metadata(self, file_path: str) -> Dict:
        """Extract metadata from document"""
        metadata = {}
        
        if file_path.endswith('.pdf'):
            with open(file_path, 'rb') as file:
                pdf = PyPDF2.PdfReader(file)
                metadata['title'] = pdf.metadata.get('/Title', '')
                metadata['page_count'] = len(pdf.pages)
                
        elif file_path.endswith('.docx'):
            doc = docx.Document(file_path)
            metadata['title'] = doc.core_properties.title or ''
            metadata['page_count'] = len(doc.paragraphs) // 50  # Rough estimate
            
        return metadata
    
    def list_files(self) -> List[Dict]:
        """List all files in storage"""
        try:
            response = self.s3_client.list_objects_v2(Bucket=self.bucket_name)
            files = []
            
            for obj in response.get('Contents', []):
                metadata = self.s3_client.head_object(
                    Bucket=self.bucket_name,
                    Key=obj['Key']
                ).get('Metadata', {})
                
                files.append({
                    "filename": obj['Key'],
                    "size": obj['Size'],
                    "last_modified": obj['LastModified'].isoformat(),
                    **metadata
                })
                
            return files
            
        except ClientError as e:
            raise Exception(f"Failed to list files: {str(e)}")

storage = DocumentStorage() 