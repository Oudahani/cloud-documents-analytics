from typing import List, Dict
from datetime import datetime
from .storage import storage

def list_documents(sort_by: str = None) -> List[Dict]:
    """List all documents with optional sorting"""
    from .processing import processor
    files = storage.list_files()
    
    if sort_by:
        return processor.sort_documents(sort_by)
    return files

def get_stats() -> Dict:
    """Get document collection statistics"""
    files = storage.list_files()
    
    total_size = sum(file.get('size', 0) for file in files)
    doc_types = {}
    
    for file in files:
        ext = file['filename'].split('.')[-1].lower()
        doc_types[ext] = doc_types.get(ext, 0) + 1
    
    return {
        "total_documents": len(files),
        "total_size_bytes": total_size,
        "document_types": doc_types,
        "last_updated": datetime.now().isoformat()
    } 