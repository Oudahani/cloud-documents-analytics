from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional
import time
from . import models, storage, processing, classification

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/upload")
def upload_document(file: UploadFile = File(...)):
    return storage.save_file(file)

@app.get("/documents")
def list_documents(sort_by: Optional[str] = None):
    return models.list_documents(sort_by)

@app.get("/search")
def search_documents(query: str):
    start = time.time()
    results = processing.search_documents(query)
    elapsed = time.time() - start
    return {"results": results, "search_time": elapsed}

@app.post("/classify")
def classify_documents():
    start = time.time()
    result = classification.classify_all()
    elapsed = time.time() - start
    return {"classification": result, "classification_time": elapsed}

@app.get("/stats")
def get_stats():
    return models.get_stats() 